<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Accueil::afficher');







use App\Controllers\Accueil;
$routes->get('accueil/afficher', [Accueil::class, 'afficher']);
//$routes->get('accueil/afficher/(:segment)', [Accueil::class, 'afficher']);





use App\Controllers\Compte;
$routes->get('compte/lister', [Compte::class, 'lister']);
$routes->match(["get","post"],'compte/creer', [Compte::class, 'creer']);
$routes->get('compte/connecter', [Compte::class, 'connecter']);
$routes->post('compte/connecter', [Compte::class, 'connecter']);
$routes->get('compte/deconnecter', [Compte::class, 'deconnecter']);
$routes->get('compte/afficher_profil', [Compte::class, 'afficher_profil']);


use App\Controllers\Actualite;
$routes->get('actualite/afficher', [Actualite::class, 'afficher']);
$routes->get('actualite/afficherone/(:num)', [Actualite::class, 'afficherone']);

use App\Controllers\Scenario;
$routes->get('scenario/afficher', [Scenario::class, 'afficher']);


use App\Controllers\Etape;
$routes->get('etape/affiche', [Etape::class, 'affiche']);
$routes->get('etape/affiche/(:segment)/(:segment)', [Etape::class, 'affiche']);

