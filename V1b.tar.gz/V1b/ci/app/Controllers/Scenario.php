<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Scenario extends BaseController
{
public function __construct()
{
//...
}
public function afficher()
{
$model = model(Db_model::class);
$data['titre']='Les Scenario:';
$data['intitule']=$model->get_scenario();

return view('templates/haut', $data)
. view('menu_visiteur')
. view('afficher_scenario')
. view('templates/bas');
}
}
