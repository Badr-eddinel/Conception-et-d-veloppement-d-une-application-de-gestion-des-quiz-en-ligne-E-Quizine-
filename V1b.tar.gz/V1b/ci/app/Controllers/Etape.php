<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Etape extends BaseController
{
public function __construct()
{
//...
}
public function affiche()
	{
	$model = model(Db_model::class);
	
$data['titre'] = 'Etape:';
$data['Etape'] = $model->get_scenario_eta($code,$nv);
return view('templates/haut', $data)
. view('menu_visiteur')
. view('afficher_scenario_eta')
. view('templates/bas');
}

    public function affiche($code,$nv)
	{
	$model = model(Db_model::class);
	
$data['titre'] = 'Etape:';
$data['Etape'] = $model->get_scenario_eta($code,$nv);
return view('templates/haut', $data)
. view('menu_visiteur')
. view('afficher_scenario_eta')
. view('templates/bas');
}
}  

