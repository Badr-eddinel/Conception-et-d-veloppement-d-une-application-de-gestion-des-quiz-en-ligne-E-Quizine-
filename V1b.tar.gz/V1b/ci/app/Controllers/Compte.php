<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Compte extends BaseController
{
public function __construct()
{
	helper('form');
//...
}
			public function connecter()
			{
			$model = model(Db_model::class);
			// L’utilisateur a validé le formulaire en cliquant sur le bouton
			if ($this->request->getMethod()=="post"){
			if (! $this->validate([
			'pseudo' => 'required',
			'mdp' => 'required'
			]))
			{ // La validation du formulaire a échoué, retour au formulaire !
			return view('templates/haut', ['titre' => 'Se connecter'])
			. view('connexion/compte_connecter')
			. view('templates/bas');
			}
			// La validation du formulaire a réussi, traitement du formulaire
			$username=$this->request->getVar('pseudo');
			$password=$this->request->getVar('mdp');
			if ($model->connect_compte($username,$password)==true)
			{
			$session=session();
			$session->set('user',$username);
			return view('templates/haut2')
			. view('connexion/compte_accueil')
			. view('templates/bas2');
			}
			else
			{ return view('templates/haut', ['titre' => 'Se connecter'])
			. view('connexion/compte_connecter')
			. view('templates/bas');
			}
			}
			// L’utilisateur veut afficher le formulaire pour se conncecter
			return view('templates/haut', ['titre' => 'Se connecter'])
			. view('connexion/compte_connecter')
			. view('templates/bas');
			}
						public function afficher_profil()
			{
			$session=session();
			if ($session->has('user'))
			{
			$data['le_message']="Affichage des données du profil ici !!!";
			// A COMPLETER...
			return view('templates/haut2',$data)
			. view('connexion/compte_profil')
			. view('templates/bas2');
			}
			else
			{
			return view('templates/haut', ['titre' => 'Se connecter'])
			. view('connexion/compte_connecter')
			. view('templates/bas');
			}
			}
			public function deconnecter()
			{
			$session=session();
			$session->destroy();
			return view('templates/haut', ['titre' => 'Se connecter'])
			. view('connexion/compte_connecter')
			. view('templates/bas');
			}
			
		

public function lister()
{
	$model = model(Db_model::class);
	$data['titre']="Liste de tous les comptes";
	$data['logins'] = $model->get_all_compte();
	$data['nombre'] = $model->get_NB_compte();
	return view('templates/haut', $data)
	. view('menu_visiteur')
	. view('affichage_comptes')
	. view('templates/bas');
}


public function creer()
	{

	$model = model(Db_model::class);
	// L’utilisateur a validé le formulaire en cliquant sur le bouton
	if ($this->request->getMethod()=="post")
	{
	if (! $this->validate([
		'nom' => 'required',
		'prenom' => 'required',
		'pseudo' => 'required|max_length[255]|min_length[2]',
		'mdp' => 'required|max_length[255]|min_length[8]',
		'mdp_confirm' => 'matches[mdp]',
		'nom' => [
        'required',
			'regex_match[/^[a-zA-Z\s]+$/]', // Vérifie que le nom ne contient que des lettres et espaces
		],
		'prenom' => [
			'required',
			'regex_match[/^[a-zA-Z\s]+$/]', // Vérifie que le prénom ne contient que des lettres et espaces
		],
		],
		
		
		[ // Configuration des messages d’erreurs
		'pseudo' => [
		'required' => 'Veuillez entrer un pseudo pour le compte !',
		],
		'nom' => [
		'required' => 'Veuillez entrer un nom pour le compte !',
		],
		'prenom' => [
		'required' => 'Veuillez entrer un prenom pour le compte !',
		],
		'mdp' => [
		'min_length' => 'Le mot de passe saisi est trop court !',
		],
		'mdp_confirm' => [
                'matches' => 'Les mots de passe ne correspondent pas !'
        ],
			'nom' => [
			'required' => 'Veuillez entrer un nom pour le compte !',
			'regex_match' => 'Le prénom ne doit pas contenir  des lettres ou des espaces !',
		],
		'prenom' => [
			'required' => 'Veuillez entrer un prénom pour le compte !',
			'regex_match' => 'Le prénom ne doit pas contenir  des lettres ou des espaces !',
		],
			'mdp' => [
			'required' => 'Veuillez entrer un mot de passe !',
			],
		]
		))
{
	// La validation du formulaire a échoué, retour au formulaire !
	return view('templates/haut', ['titre' => 'Créer un compte'])
	. view('compte/compte_creer');
	
}


  

        
         
        $pseudo = $this->request->getPost('pseudo');

        // Vérification si le pseudo existe déjà dans la base de données
       
			if ($model->pseudoExists($pseudo)) {
				$this->validator->setError('pseudo', 'Ce pseudo est déjà utilisé !');
				return view('templates/haut', ['titre' => 'Créer un compte'])
					. view('compte/compte_creer');
			}



	// La validation du formulaire a réussi, traitement du formulaire
	$recuperation = $this->validator->getValidated();
	$statut = $this->request->getPost('statut');
	$validite = $this->request->getPost('validite');
	$model->set_compte($recuperation,$validite,$statut);
	
	$data['le_compte']=$recuperation['pseudo'];
	$data['le_message']="Bravo ! Formulaire rempli, le compte suivant a été ajouté" ;
	//Appel de la fonction créée dans le précédent tutoriel :
	$data['nombre']=$model->get_NB_compte();
	return view('templates/haut', $data)
	. view('compte/compte_succes');
	
	
}

	// L’utilisateur veut afficher le formulaire pour créer un compte
	return view('templates/haut', ['titre' => 'Créer un compte'])
	. view('compte/compte_creer');
	

	}



}









