<?php
/******************************************
 * NOm Fichier:db_model
 =============================
 * description
 * =====================================
 * auteur=
 * =================
 * date derniere modification
 * vertion
 * ========================
 * ********************************************/
namespace App\Models;
use CodeIgniter\Model;
class Db_model extends Model
{
	
protected $db;
public function __construct()
{
$this->db = db_connect(); //charger la base de données
// ou
// $this->db = \Config\Database::connect();
}
/*================================================
 gestion CRUD des comptes
==================================================*/
public function get_all_compte()
{
$resultat = $this->db->query("SELECT * FROM t_compte_cmp JOIN t_profil_pfl using (cmp_id) ORDER BY pfl_validite;");
return $resultat->getResultArray();
}


public function get_actualite()
    {
    $requete="SELECT * FROM t_actualite_act  JOIN t_compte_cmp using (cmp_id) where act_etat='A';";
    $resultat = $this->db->query($requete);
    return $resultat->getResultArray();
    }
    
    public function get_actualite_one($numero)
{
$requete="SELECT * FROM t_actualite_act JOIN t_compte_cmp using (cmp_id) WHERE act_etat='A' AND act_id=".$numero.";";
$resultat = $this->db->query($requete);
return $resultat->getRow();
}
    
    
    

    public function get_NB_compte()
{
$resultat = $this->db->query("SELECT COUNT(cmp_id) AS NB FROM t_compte_cmp;");
return $resultat->getRow();
}
public function get_scenario()
    {
   $requete="SELECT scn_intitule AS Intitule,
       cmp_login AS Auteur,
       scn_image AS img,
       scn_code AS code,
       reu_niveau AS niveau
FROM t_scenario_scn 
LEFT JOIN t_compte_cmp using (cmp_id)
LEFT JOIN t_score_reu  using (scn_id)
WHERE scn_activiescenario = 'A'
;
";
    $resultat = $this->db->query($requete);
    return $resultat->getResultArray();
    }
    
    public function get_scenario_eta($code ,$nv )
    {
		
		$requete="SELECT eta_intitule AS IntituleEtape,
		ind_desc AS Indice,
		eta_descreption AS descr,
		eta_question As ques,
		ind_lien As lien
		FROM t_etape_eta 
		LEFT JOIN t_scenario_scn ON  t_scenario_scn.scn_id = t_etape_eta.scn_id
		LEFT JOIN t_indice_ind ON t_indice_ind.eta_id = t_etape_eta.eta_id AND ind_niveau = '".$nv."'
		WHERE scn_code ='".$code."'  ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    



public function pseudoExists($pseudo) {
    
       $requete=" SELECT cmp_login FROM t_compte_cmp WHERE cmp_login='".$pseudo."';";
       $resultat = $this->db->query($requete);
       return $resultat->getRow();
    //return ($resultat!== null); // Si $result n'est pas vide, le pseudo existe déjà
}


public function set_compte($saisie,$validite,$statut)

{
    $this->db->transStart(); // Début de la transaction

    try {
        $login = $saisie['pseudo'];
        $mot_de_passe = $saisie['mdp'];
        $nom = $saisie['nom'];
        $prenom = $saisie['prenom'];
        
        
        

        // Insertion dans la table t_compte_cmp
        $sqlCompte = "INSERT INTO t_compte_cmp VALUES(NULL,'".$mot_de_passe."','".$login."');";
        $this->db->query($sqlCompte, [$login, $mot_de_passe]);
        $insertedCmpId = $this->db->insertID(); // Récupération de l'ID inséré dans t_compte_cmp

        // Insertion dans la table t_profil_pfl
        $sqlProfil = "INSERT INTO `t_profil_pfl` (`pfl_id`, `pfl_nom`, `pfl_prenom`, `pfl_validite`, `pfl_role`, `cmp_id`) VALUES (NULL, '".$nom."', '".$prenom."', '".$validite."', '".$statut."', '".$insertedCmpId."');";
        $this->db->query($sqlProfil, [$nom, $prenom, $insertedCmpId]);

        $this->db->transComplete(); // Fin de la transaction

        if ($this->db->transStatus() === false) {
            $this->db->transRollback(); // Annulation de la transaction si elle a échoué
            return false;
        } else {
            $this->db->transCommit(); // Validation de la transaction si tout s'est bien passé
            return true;
        }
    } catch (\Exception $e) {
        $this->db->transRollback(); // En cas d'exception, annulation de la transaction
        return false;
    }
}
				public function connect_compte($u,$p)
				{
				$sql="SELECT cmp_login,cmp_mdp
				FROM t_compte_cmp
				WHERE cmp_login='".$u."'
				AND cmp_mdp='".$p."';";
				$resultat=$this->db->query($sql);
				if($resultat->getNumRows() > 0)
				{
				return true;
				}
				else
				{
				return false;
				}
				}
}









    





