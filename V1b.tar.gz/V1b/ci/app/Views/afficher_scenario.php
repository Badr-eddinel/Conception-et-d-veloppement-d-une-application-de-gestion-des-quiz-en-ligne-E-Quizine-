

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
       body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
}

.scenarios-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    padding: 20px;
}

.scenario {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 10px;
    margin: 10px;
    width: 300px;
    background-color: #fff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
.scenario h3 {
    font-size: 18px;
    color: #333;
    margin-bottom: 10px;
}

/* Styles pour les balises p */
.scenario p {
    font-size: 14px;
    color: #666;
    line-height: 1.5;
    margin-bottom: 10px;
}

/* Styles pour les balises img */
.scenario img {
    max-width: 100%;
    height: auto;
    display: block;
    margin-bottom: 10px;
}

.scenario img {
    max-width: 100%;
    height: 200px; 
    object-fit: cover; 
}
.difficulty-level {
    border: 2px solid transparent;
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 20px;
    transition: all 0.3s ease;
}

.difficulty-level:hover {
    border-color: #333; /* Couleur de la bordure au survol */
}

.easy {
    background-color: #d4edda; /* Fond pour le niveau FACILE */
}

.medium {
    background-color: #fff3cd; /* Fond pour le niveau MOYEN */
}

.hard {
    background-color: #f8d7da; /* Fond pour le niveau DIFFICILE */
}

    </style>
    <title>Tableau PHP</title>
</head>
<body>

    <div class="scenarios-container">
        <?php
        if (empty($intitule) ) {
                    echo ("Pas de scenario disponible pour le moment.");
                } 
            
                
        elseif ( isset($intitule) )
{
foreach ($intitule as $pseudos)
{
	
            
				echo "<div class='scenario'>";
				echo "<h3>" . $pseudos["Intitule"] . "</h3>";
				echo "<img width='500' src='" . base_url('ressources/') . $pseudos["img"] . "'>";
				echo "<br />";

				// Cadre pour le niveau FACILE
				echo "<p>Niveau de difficulté: </p>";
				echo "<div class='difficulty-level easy'>";
				echo "<a href='" . base_url('index.php/etape/affiche/') . $pseudos["code"] . "/1'> NIVEAU FACILE </a>";
				echo "</div>";

				// Cadre pour le niveau MOYEN
				echo "<p>Niveau de difficulté: </p>";
				echo "<div class='difficulty-level medium'>";
				echo "<a href='" . base_url('index.php/etape/affiche/') . $pseudos["code"] . "/2'> NIVEAU MOYEN </a>";
				echo "</div>";

				// Cadre pour le niveau DIFFICILE
				echo "<p>Niveau de difficulté: </p>";
				echo "<div class='difficulty-level hard'>";
				echo "<a href='" . base_url('index.php/etape/affiche/') . $pseudos["code"] . "/3'> NIVEAU DIFFICILE </a>";
				echo "</div>";

				echo "<br />";
				echo "<p>Auteur: " . $pseudos["Auteur"] . "</p>";

				echo "</div>";

                }
            } else {
                // Aucun scénario disponible
                echo "<p>Aucun scénario disponible pour le moment.</p>";
            }
		

            
        ?>
    </div>

</body>
</html>

