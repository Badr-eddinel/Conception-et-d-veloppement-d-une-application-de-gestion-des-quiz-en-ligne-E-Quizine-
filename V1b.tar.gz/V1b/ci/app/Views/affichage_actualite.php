
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        table {
            width: 80%;
            margin: 50px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
    <title>Tableau PHP</title>
</head>
<body>
<h1><?php echo $titre;?></h1><br/> 	

    <table>
        <thead>
            <tr>
                <th>Intitule</th>
                <th>decription</th>
                <th>date</th>
                <th>Auteur</th>
                <th>Info</th>
            </tr>
        </thead>
        <tbody>
	
<?php
if (isset($new)){


                    echo "<tr>";
                    echo "<td>" . $new->act_intitule . "</td>";
                    echo "<td>" . $new->act_desc . "</td>";
                    echo "<td>" . $new->act_date . "</td>";
                     echo "<td>" . $new->cmp_login . "</td>";
                    
                    echo "</tr>";
}



?>		
			
			
			
            <?php
            if (empty($news) AND empty($new)) {
                    echo ("Pas d'actualités disponibles pour le moment.");
                } 
            
                elseif (isset($news) )
{
foreach ($news as $pseudos)
{
                

                
                    echo "<tr>";
                    echo "<td>" . $pseudos["act_intitule"] . "</td>";
                    echo "<td>" . $pseudos["act_desc"] . "</td>";
                    echo "<td>" . $pseudos["act_date"] . "</td>";
                    echo "<td>" . $pseudos["cmp_login"] . "</td>";
                    echo "<td>" ;
                   
                    
                     echo "<a href='" . base_url('index.php/actualite/afficherone/') . $pseudos["act_id"] . "'> Info </a>";
                     echo "</td>";
                    
                    
                    echo "</tr>";
                }
			} 
			


            ?>
            
        </tbody>
    </table>

</body>
</html>

                
