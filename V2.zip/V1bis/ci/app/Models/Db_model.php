<?php
/******************************************
 * NOm Fichier:db_model
 =============================
 * description
 * =====================================
 * auteur=badreddineelhadeq
 * =================
 * date derniere modification 10/12/2023
 * vertion V2
 * ========================
 * ********************************************/
namespace App\Models;
use CodeIgniter\Model;
class Db_model extends Model
{
	
protected $db;
public function __construct()
{
$this->db = db_connect(); //charger la base de données
// ou
// $this->db = \Config\Database::connect();
}
/*================================================
 gestion CRUD des comptes
==================================================*/
public function get_all_compte()
{
	$resultat = $this->db->query("SELECT * FROM t_compte_cmp JOIN t_profil_pfl using (cmp_id) ORDER BY pfl_validite;");
	return $resultat->getResultArray();
}


public function get_actualite()
    {
    $requete="SELECT * FROM t_actualite_act  JOIN t_compte_cmp using (cmp_id) where act_etat='A';";
    $resultat = $this->db->query($requete);
    return $resultat->getResultArray();
    }
    
    public function get_actualite_one($numero)
{
	$requete="SELECT * FROM t_actualite_act JOIN t_compte_cmp using (cmp_id) WHERE act_etat='A' AND act_id=".$numero.";";
	$resultat = $this->db->query($requete);
	return $resultat->getRow();
}
    
    
    

    public function get_NB_compte()
{
	$resultat = $this->db->query("SELECT COUNT(cmp_id) AS NB FROM t_compte_cmp;");
	return $resultat->getRow();
}
public function get_scenario()
    {
   $requete="SELECT scn_id AS ID,
   scn_intitule AS Intitule,
       cmp_login AS Auteur,
       scn_image AS img,
       scn_code AS code,
       scn_activiescenario AS Active,
       scn_decsenario AS decription,
       reu_niveau AS niveau FROM t_scenario_scn LEFT JOIN t_compte_cmp using (cmp_id) LEFT JOIN t_score_reu  using (scn_id) WHERE scn_activiescenario = 'A'
;
";
    $resultat = $this->db->query($requete);
    return $resultat->getResultArray();
    }
    
    
    public function get_scenario_one($one)
    {
   $requete="SELECT scn_id AS ID,
   scn_intitule AS Intitule,
       cmp_login AS Auteur,
       scn_image AS img,
       scn_code AS code,
       scn_activiescenario AS Active,
       scn_decsenario AS decription,
       reu_niveau AS niveau
		FROM t_scenario_scn 
		LEFT JOIN t_compte_cmp using (cmp_id)
		LEFT JOIN t_score_reu  using (scn_id)
		WHERE scn_code ='".$one."';";

    $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    
    public function get_scenario_all()
    {
	   $requete="SELECT scn_id AS ID,
	scn_intitule AS Intitule,
	cmp_login AS Auteur,
	scn_image AS img, 
	scn_code AS code, 
	scn_activiescenario AS Active,
	scn_decsenario AS decription,
	COUNT(eta_id) As NB 
	FROM t_scenario_scn LEFT JOIN t_compte_cmp using (cmp_id) LEFT JOIN t_etape_eta using (scn_id) GROUP by scn_id order by cmp_login

;
";
    $resultat = $this->db->query($requete);
    return $resultat->getResultArray();
    }
    
    

    
    
    public function get_scenario_eta($code ,$nv)
    {
		
		$requete="SELECT eta_intitule AS IntituleEtape,
		 ind_desc AS Indice, 
		 eta_descreption AS descr, 
		 eta_question As ques, 
		 ind_lien As lien 
		 FROM t_scenario_scn 
		 LEFT JOIN t_etape_eta USING(scn_id) 
		 LEFT JOIN t_indice_ind ON t_indice_ind.eta_id = t_etape_eta.eta_id AND ind_niveau = '" . $nv . "' 
		WHERE scn_code ='" . $code . "' AND eta_numero=1 ;";
		
		
		   
	  $resultat = $this->db->query($requete);
      return $resultat->getRow();
    }
   
    public function get_scenario_etape($code)
{
    $requete = "SELECT eta_intitule AS IntituleEtape,
                        eta_descreption AS descr,
                        eta_question AS ques
                FROM t_etape_eta 
                LEFT JOIN t_scenario_scn ON t_scenario_scn.scn_id = t_etape_eta.scn_id
                WHERE scn_code = '" . $code . "';";

    $resultat = $this->db->query($requete);
    return $resultat->getRow();
}
public function get_scenario_fetape($code)
{
    $requete = "SELECT eta_intitule AS IntituleEtape,
		 ind_desc AS Indice, 
		 eta_descreption AS descr, 
		 eta_question As ques, 
		 ind_lien As lien 
		 FROM t_scenario_scn 
		 LEFT JOIN t_etape_eta USING(scn_id) 
		 LEFT JOIN t_indice_ind ON t_indice_ind.eta_id = t_etape_eta.eta_id 
                
                WHERE eta_code = '" . $code . "';";

    $resultat = $this->db->query($requete);
    return $resultat->getRow();
}

/*-----------------------------------------------------
 -------------------------------------------------------*/
 
public function incrementation($numero) {
    $sql = "SELECT IncrementerEtaNumero($numero) AS eta_numero_out;";
    
    // Exécuter la requête SQL et récupérer le résultat
    $result = $this->db->query($sql)->getRow();
    
    // Récupérer la valeur de eta_numero_out depuis le résultat
    $eta_numero_out = $result->eta_numero_out;
    
    return $eta_numero_out;
}

public function get_etanumeroo($code)
    {
		
		$requete="SELECT eta_numero FROM t_etape_eta 


		WHERE eta_code = '".$code."'
		 ;";
		   
    $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    
    public function get_prochaine_etape($code,$id)
    {
		
				$requete="SELECT eta_code FROM t_etape_eta 
		JOIN t_scenario_scn ON t_scenario_scn.scn_id = t_etape_eta.scn_id

		WHERE t_scenario_scn.scn_code = '".$code."' 
		AND eta_numero = '".$id."'
		 ;";
		   
	  $resultat = $this->db->query($requete);
		return $resultat->getRow();
    }
    
    public function get_prochaine($id,$idcenario)
    {
		
		$requete="SELECT eta_code FROM t_etape_eta join t_scenario_scn using (scn_id) WHERE scn_id = '".$idcenario."' and eta_numero = '".$id."';";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    
    public function get_reponse_etape($code)
    {
		
		$requete="SELECT eta_reponse FROM t_etape_eta  WHERE eta_code ='".$code."'   ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    public function get_reponse_attendue($code)
    {
		
		$requete="SELECT eta_reponse FROM t_etape_eta JOIN t_scenario_scn using(scn_id) WHERE scn_code ='".$code."' and eta_numero=1  ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    



public function pseudoExists($pseudo) {
    
       $requete=" SELECT cmp_login FROM t_compte_cmp WHERE cmp_login='".$pseudo."';";
       $resultat = $this->db->query($requete);
       return $resultat->getRow();
    //return ($resultat!== null); // Si $result n'est pas vide, le pseudo existe déjà
}


public function set_compte($saisie,$validite,$statut)

{
   

    
        $login = $saisie['pseudo'];
        $mot_de_passe = $saisie['mdp'];
        $nom = $saisie['nom'];
        $prenom = $saisie['prenom'];
        
        $userspassword = "CeciEstMonMotdePasse!123";
        $salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";
        $password1 = hash('sha256', $salt.$userspassword.$mot_de_passe);
        
        

        // Insertion dans la table t_compte_cmp
        $sqlCompte = "INSERT INTO t_compte_cmp VALUES(NULL,'".$password1."','".$login."');";
        $this->db->query($sqlCompte);
        $insertedCmpId = $this->db->insertID(); 

        // Insertion dans la table t_profil_pfl
        $sqlProfil = "INSERT INTO `t_profil_pfl` (`pfl_id`, `pfl_nom`, `pfl_prenom`, `pfl_validite`, `pfl_role`, `cmp_id`) VALUES (NULL, '".$nom."', '".$prenom."', '".$validite."', '".$statut."', '".$insertedCmpId."');";
        $this->db->query($sqlProfil);

        

	}

				public function connect_compte($u,$p)
				{ $userspassword = "CeciEstMonMotdePasse!123";
        $salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";
        $password1 = hash('sha256', $salt.$userspassword.$p);
					
					
				$sql="SELECT cmp_login,cmp_mdp
				FROM t_compte_cmp
				WHERE cmp_login='".$u."'
				AND cmp_mdp='".$password1."';";
				$resultat=$this->db->query($sql);
				if($resultat->getNumRows() > 0)
				{
				return true;
				}
				else
				{
				return false;
				}
				}
				
				public function get_profil($user){
					$requete="SELECT *
				FROM t_compte_cmp JOIN t_profil_pfl using (cmp_id)
				WHERE cmp_login='".$user."';";
				$resultat = $this->db->query($requete);
return $resultat->getRow();
				}
				
				public function verifi_mot_de_passe($user){
					$requete="SELECT cmp_id
				FROM t_compte_cmp 
				WHERE cmp_login='".$user."';";
				$resultat = $this->db->query($requete);
return $resultat->getRow();
				}
					
				
				public function set_mot_de_passe($user,$nouveauMotDePasse) {
					$userspassword = "CeciEstMonMotdePasse!123";
        $salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";
        $password1 = hash('sha256', $salt.$userspassword.$nouveauMotDePasse);
        
        
					
				$requete = "UPDATE  t_compte_cmp
                SET cmp_mdp = '" . $password1 . "'
                WHERE cmp_login = '" . $user . "';";

				
				$resultat = $this->db->query($requete);

				if ($resultat) {
					return true;
				} else {
					return false;
				}
				
				 
			}
			
			public function getUserRole($username){
				$requete="SELECT pfl_role
				FROM t_compte_cmp JOIN t_profil_pfl using (cmp_id)
				WHERE cmp_login='".$username."';";
				$resultat = $this->db->query($requete);
return $resultat->getRow()->pfl_role;
				
			}
			
			
			  public function get_nombre_eta($code)
{
$resultat = $this->db->query("SELECT COUNT(eta_id) AS NB FROM t_etape_eta JOIN t_scenario_scn ON  t_scenario_scn.scn_id = t_etape_eta.scn_id WHERE scn_code ='".$code."';");
return $resultat->getRow();
}

public function inser_scnario($intitule,$etat,$nom_fichier,$description,$codeAleatoire,$id)
{
$resultat = $this->db->query("INSERT INTO `t_scenario_scn` (`scn_id`, `scn_intitule`, `scn_image`, `scn_decsenario`, `scn_activiescenario`, `scn_code`, `cmp_id`) VALUES
 (NULL, '".$intitule."', '".$nom_fichier."', '".$description."', '".$etat."', '".$codeAleatoire."','".$id."');");
 
return $resultat;
}

public function get_liste_q($code)  
{
$requete="SELECT eta_question As ques,
                 eta_reponse As rep
				FROM t_etape_eta  
				JOIN t_scenario_scn ON  t_scenario_scn.scn_id = t_etape_eta.scn_id
				WHERE scn_code ='".$code."';";
				$resultat = $this->db->query($requete);
return $resultat->getResultArray();
}



public function supprimer_scenario($scenario_id) {
    $sql = "CALL supprimer_scenario_etapes($scenario_id);";
    
    // Exécuter la requête SQL
    return $this->db->query($sql);
}

public function get_id($username)  
{
$requete="SELECT cmp_id 
                 FROM t_compte_cmp 
				WHERE cmp_login ='".$username."';";
				$resultat = $this->db->query($requete);
return $resultat->getRow();
}
public function genererCodeAleatoire() {
    $longueur = 8; // Longueur du code
    $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; // Caractères autorisés
    $code = '';

    // Générer le code aléatoire en mélangeant les caractères
    for ($i = 0; $i < $longueur; $i++) {
        $code .= $caracteres[rand(0, strlen($caracteres) - 1)];
    }

    return $code;
}


public function inser_adresse($reponse_saisie)
    {
		
		$requete="INSERT INTO `t_participant_par` (`par_id`, `par_adresse`) VALUES (NULL, '".$reponse_saisie."') ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat;
    }
    public function select_id($reponse_saisie)
    {
		
		$requete="SELECT par_id FROM t_participant_par 


WHERE par_adresse = '".$reponse_saisie."'
 ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    public function select_id_scn($code)
    {
		
		$requete="SELECT scn_id FROM t_etape_eta where eta_code='".$code."' ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    public function inser_score($id1,$id2,$nv)
    {
		
		$requete="INSERT INTO `t_score_reu` (`reu_datepremiere`, `reu_datederniere`, `reu_niveau`, `scn_id`, `par_id`) VALUES (curdate(), NULL, '".$nv."', '".$id1."', '".$id2."')



 ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();        
    }
    
    
      public function get_scn($code)
    {
		
		$requete="SELECT scn_id FROM  t_etape_eta  join t_scenario_scn using (scn_id) WHERE eta_code ='".$code."'   ;";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
    
     public function count($code)
    {
		
		$requete="SELECT COUNT(eta_id) AS NNB FROM t_etape_eta WHERE scn_id in(select scn_id from t_etape_eta where eta_code='".$code."') ";
		   
  $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }
     
    
    
}



















 

 





    





