<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Scenario extends BaseController
{
public function __construct()
{
//...
}
public function afficher()
{
	 
		$model = model(Db_model::class);
		$data['titre']='Les Scenario:';
		$data['intitule']=$model->get_scenario();

		return view('templates/haut', $data)
		. view('menu_visiteur')
		. view('afficher_scenario')
		. view('templates/bas');
		
}

public function afficher_detaille()
{
	$session=session();
	if ($session->has('user')) {
		$model = model(Db_model::class);
		$data['titre']='Les Scenario:';
		$data['intitule']=$model->get_scenario_all();
		$data['NB']=$model->get_nombre_eta($code);
		return view('templates/haut', $data)
		. view('menu_organisateur')
		. view('afficher_scenario_org')
		. view('templates/bas');
		}else{
			return redirect()->to(base_url('index.php'));}
}
public function afficher_detailler($code)
{
	$session=session();
	if ($session->has('user')) {
		$model = model(Db_model::class);
		$data['titre']='Le Scenario:';
		$data['intitule']=$model->get_scenario_one($code);
		$data['liste']=$model->get_liste_q($code);
		$data['NB']=$model->get_nombre_eta($code);
		return view('templates/haut', $data)
		. view('menu_organisateur')
		. view('afficher_detailler')
		. view('templates/bas');
		}else{
			return redirect()->to(base_url('index.php'));}
}

public function ajouter()
{
	$session=session();
    helper('form');
    $model = model(Db_model::class);       

    if (!session()->has('user')) {
        // Rediriger vers la page de connexion si la session n'est pas active
        return redirect()->to('/compte/connecter');
    }

    if ($this->request->getMethod() == "post") {

        if (!$this->validate([
            'intitule' => [
                'rules' => 'required|regex_match[/^[a-zA-Z ]+$/]',
                'errors' => [
                    'required' => 'Veuillez entrer un intitulé pour le scénario !',
                    'regex_match' => 'L\'intitulé ne doit contenir que des lettres et espaces !',
                ],
            ],
            'description' => [
                'rules' => 'required|regex_match[/^[a-zA-Z ]+$/]',
                'errors' => [
                    'required' => 'Veuillez entrer une description pour le scénario !',
                    'regex_match' => 'La description ne doit contenir que des lettres et espaces !',
                ],
            ],
            'etat' => [
                'rules' => 'required',
                'errors' => [
                    'required' => 'Veuillez entrer un état pour le scénario !',
                ],
            ],
            'fichier' => [
                'rules' => 'uploaded[fichier]|is_image[fichier]|mime_in[fichier,image/jpg,image/jpeg,image/gif,image/png,image/webp]|max_size[fichier,1024]',
                'errors' => [
                    'uploaded' => 'Veuillez sélectionner un fichier à téléverser !',
                    'is_image' => 'Le fichier doit être une image (jpg, jpeg, gif, png, webp) !',
                    'mime_in' => 'Le fichier doit être une image valide (jpg, jpeg, gif, png, webp) !',
                    'max_size' => 'Le fichier ne doit pas dépasser 1 Mo !',
                ],
            ],
        ])) {
            // La validation du formulaire a échoué, retour au formulaire avec les messages d'erreur
            return view('templates/haut', ['titre' => 'Créer un scenario'])
                . view('menu_organisateur')
                . view('scenario/ajouter_scn');
        }

        // Autre traitement si la validation réussit...
    


// La validation du formulaire a réussi, traitement du formulaire
//$recuperation = $this->validator->getValidated();
$session = session();
$username = $session->get('user');

$intitule=$this->request->getVar('intitule');
$etat=$this->request->getVar('etat');
$description=$this->request->getVar('description');
$fichier=$this->request->getFile('fichier');
$codeAleatoire = $model->genererCodeAleatoire();
    $object = $model->get_id($username);
    $id = $object->cmp_id;

		if(!empty($fichier)){
			//return redirect()->to('');
			// Récupération du nom du fichier téléversé
		   
			$nom_fichier=$fichier->getName();
			// Dépôt du fichier dans le répertoire ci/public/images
			if($fichier->move("ressources",$nom_fichier)){
			// + Mettre ici l’appel de la fonction membre du Db_model
				$model->inser_scnario($intitule,$etat,$nom_fichier,$description,$codeAleatoire,$id);

				
				$data['message'] = 'Le scénario a été ajouté avec succès.';
				// + L’affichage de la page indiquant l’ajout du compte !
				return view('templates/haut',$data)
				. view('menu_organisateur')
				. view('scenario/ajout_succes');
				
				}
        }

}

// L’utilisateur veut afficher le formulaire pour créer un compte
 // La validation du formulaire a échoué, retour au formulaire !
 return view('templates/haut',['titre' => 'Créer un scenario'])    
 .view('menu_organisateur')
 . view('scenario/ajouter_scn');
 
}
public function supprimer($scenario_id) {
	$model = model(Db_model::class);       
    $session=session();
     if (!session()->has('user')) {
     // Rediriger vers la page de connexion si la session n'est pas active
     return redirect()->to('/compte/connecter');
    }
    $model = model(Db_model::class);
      
    $model->supprimer_scenario($scenario_id);
    
    return redirect()->to('/scenario/afficher_detaille');
}








public function franchir_etape($code = NULL, $nv=0)
{
	
	helper('form');
	$model = model(Db_model::class);
    // Vérifie si le formulaire a été soumis en POST
    if ($this->request->getMethod() == "post") {
        // Récupération de la réponse saisie dans le champ 'reponse' du formulaire
        $reponse_saisie = $this->request->getPost('reponse');
        
        // Récupération de la réponse attendue depuis la base de données
        
        $reponse_attendue = $model->get_reponse_etape($code); // Supposons que vous avez une méthode pour récupérer la réponse attendue
        $reponse = $reponse_attendue->eta_reponse;
        
        // Comparaison des réponses
        if ($reponse_saisie == $reponse) {
			$message = "Bonne réponse";
			$numero= $model->get_etanumeroo($code);
			$numeroo = $numero->eta_numero;
			
			$nb= $model->count($code);
            $nba = $nb->NNB;
            
            $idet = $model->incrementation($numeroo);
             $id = $idet->eta_numero_out;
             
             if($id<$nba){return redirect()->to('/scenario/finaliser/'. $code.'/' . $nv);}
             $idcenario = $model->get_scn($code);
             $idscn = $idcenario->scn_id;
            $prochaine_etape = $model->get_prochaine($idet,$idscn);
            
            $lecode = $prochaine_etape->eta_code;
            
            return redirect()->to('/scenario/franchir_etape/'. $lecode.'/' . $nv);
        } else {
			$message = "Mauvaise réponse";
            // Si la réponse est incorrecte, vous pouvez rediriger vers la même étape ou afficher un message d'erreur
            return redirect()->to('/scenario/franchir_etape/'. $code.'/' . $nv);
        }
    }

    // Affichage du formulaire si aucun formulaire n'a été soumis
    if ($code != NULL) {
        // Récupération des données pour afficher l'étape actuelle
      
		$data['titre'] = 'Etape:';
		$data['Etape'] = $model->get_scenario_fetape($code);
		 $data['lecode'] = $code;
		 $data['lenv']=$nv;
		 $data['message'] = $message;
		return view('templates/haut', $data)
		. view('menu_visiteur')
		. view('scenario/formulaire_scenaro')
		. view('templates/bas');
		}
    }


    public function finaliser($code = NULL, $nv=0)
{
    helper('form');
    $model = model('Db_model');

    // Vérifie si le formulaire a été soumis en POST
    if ($this->request->getMethod() == 'post') {
        if (! $this->validate([
			'reponse' => 'required',
			
		]))
		{ 
        
            $data['message'] = 'Entrer votre adresse.';
            $data['lecode'] = $code;
            $data['lenv']=$nv;
            return view('templates/haut', $data)
                . view('menu_visiteur')
                . view('scenario/formulaire_premiere_etape')
                . view('templates/bas');
        }
	

        $reponse_saisie = $this->request->getPost('reponse');
       
	    $model->inser_adresse($reponse_saisie);
		$id1=$model->select_id($reponse_saisie);
		$id1=$model->select_id_scn($code);
		//$model->inser_score($id1,$id2,$nv);
		return redirect()->to('/scenario/afficher');
		if($model->inser_adresse($reponse_saisie)){return redirect()->to('/scenario/afficher');}
    }
    $data['message'] = 'Entrer votre adresse.';
            $data['lecode'] = $code;
            $data['lenv']=$nv;
            return view('templates/haut', $data)
                . view('menu_visiteur')
                . view('scenario/formulaire_premiere_etape')
                . view('templates/bas');
}

}











 
 






