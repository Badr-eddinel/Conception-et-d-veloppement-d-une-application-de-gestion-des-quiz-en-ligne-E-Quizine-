<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Etape extends BaseController
{
public function __construct()
{
//...
}


    public function affiche($code=NULL, $nv=0)
{
	helper('form');
    $model = model(Db_model::class);
    
      if ($this->request->getMethod() == "post") {
		  //return redirect()->to('');
		 
        // Récupération de la réponse saisie dans le champ 'reponse' du formulaire
     
        $reponse_saisie=$this->request->getVar('reponse');
        
        // Récupération de la réponse attendue depuis la base de données
        
        $reponse_attendue = $model->get_reponse_attendue($code); // Supposons que vous avez une méthode pour récupérer la réponse attendue
        $reponse = $reponse_attendue->eta_reponse;
       
        // Comparaison des réponses
        if ($reponse_saisie == $reponse) {
			//return redirect()->to('');
            // Si la réponse saisie correspond à la réponse attendue, effectuez les actions nécessaires pour passer à la prochaine étape
            $numero= 1;
            $idet = $model->incrementation($numero);
             $id = $idet->eta_numero_out;
            $prochaine_etape = $model->get_prochaine_etape($code,$idet);
            
            $lecode = $prochaine_etape->eta_code;
            if($prochaine_etape==null){return redirect()->to('/');}
             // Supposons que vous avez une méthode pour obtenir la prochaine étape
            // Redirection vers la prochaine étape
            return redirect()->to('/scenario/franchir_etape/'. $lecode.'/' . $nv);
        } else {
            // Si la réponse est incorrecte, vous pouvez rediriger vers la même étape ou afficher un message d'erreur
            return redirect()->to('/etape/affiche/' . $code . '/' . $nv);
        }
    }
    
    if($code!=NULL){
    
    $data['titre'] = 'Etape:';
    $data['Etape'] = $model->get_scenario_eta($code, $nv);
    $data['lecode']=$code;
    $data['lenv']=$nv;
    }
    return view('templates/haut', $data)
        . view('menu_visiteur')
        . view('afficher_scenario_eta')
        . view('templates/bas');
}


}


