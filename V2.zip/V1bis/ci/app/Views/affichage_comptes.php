

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        table {
            width: 80%;
            margin: 50px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
				* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
		}

		/* Styles pour le bouton d'ajout */
		.add-button {
			display: inline-block;
			padding: 10px 20px;
			text-decoration: none;
			background-color: #3498db; /* Couleur de fond */
			color: #fff; /* Couleur du texte */
			border-radius: 5px;
			transition: background-color 0.3s ease; /* Transition pour l'animation au survol */
		}

		.add-button:hover {
			background-color: #2980b9; /* Changement de couleur au survol */
		}

		.container {
			/* Ajoutez ici le style de votre conteneur principal si nécessaire */
		}
    </style>
    <title>Tableau PHP</title>
</head>
		<body>
			<h1><?php echo $titre;?></h1><br/>
			<h1>le nombre du compte</h1><br/>  
			<p><?php echo $nombre->NB;?></p><br/> 		

       <table>
         <thead>
            <tr>
                <th>Prenom</th>
                <th>Nom</th>
                <th>Role</th>
                <th>Validite</th>
                <th>Auteur</th>
            </tr>
         </thead>
        <tbody>
	
				<?php
					if (empty($logins)) {
						echo ("Pas profil disponibles pour le moment.");
					} 
				
					elseif (isset($logins) )
						{
						foreach ($logins as $pseudos)
							{
								
									echo "<tr>";
									echo "<td>" . $pseudos["pfl_prenom"] . "</td>";
									echo "<td>" . $pseudos["pfl_nom"] . "</td>";
									echo "<td>" . $pseudos["pfl_role"] . "</td>";
									echo "<td>" . $pseudos["pfl_validite"] . "</td>";
									echo "<td>" . $pseudos["cmp_login"] . "</td>";
									
									
									echo "</tr>";
							  }
						    } 
							


				?>
            <a href="<?= base_url('index.php/compte/creer') ?>" class="add-button">Ajouter un nouveau compte/profil</a>

        </tbody>
    </table>

</body>
</html>
