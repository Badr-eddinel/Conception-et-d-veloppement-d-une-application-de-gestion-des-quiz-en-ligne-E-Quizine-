<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
            text-transform: uppercase;
            font-size: 14px;
        }

        tr:hover {
            background-color: #f9f9f9;
        }

        .icon-column {
            font-size: 20px;
        }

        .icon-column a {
            color: #333;
            text-decoration: none;
            margin: 0 5px;
            transition: color 0.3s ease;
        }

        .icon-column a:hover {
            color: #ff6b6b;
        }

        .no-data {
            text-align: center;
            padding: 20px;
            color: #555;
        }
    </style>
    <title>Tableau PHP</title>
</head>
<body>
    <h1><?php echo $titre; ?></h1><br/> 
    <a href="<?php echo base_url('index.php/scenario/ajouter'); ?>" class="cancel-link">AJOUTER</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Intitulé</th>
                <th>Code</th>
                <th>Image</th>
                <th>Statue</th>
                <th>Nombre Étapes</th> 
                <th>Auteur</th>
                <th>View</th>
                <th>Modifier</th>
                <th>copier</th>
                <th>Supprimer</th>
                <th>Activer/desactiver</th>
                <th>Remise a zero</th>
                
            </tr>
        </thead>
        
        <tbody>
            <?php
            $session = session();

            if (empty($intitule)) { 
                echo '<tr>
                        <td colspan="12">Pas de scénario disponible pour le moment.</td>
                    </tr>';
            } else {
               foreach ($intitule as $pseudos) {
            

            echo '<tr>
                <td>' . $pseudos["ID"] . '</td>
                <td>' . $pseudos["Intitule"] . '</td>
                <td>' . $pseudos["code"] . '</td>
                <td>' . $pseudos["img"] . '</td>
                <td>' . $pseudos["Active"] . '</td>
                <td>' . $pseudos["NB"] . '</td>
                <td>' . $pseudos["Auteur"] . '</td>';

                    if ($session->get('user') == $pseudos["Auteur"]) {
                        echo '<td class="icon-column">
                                <a href="' . base_url('index.php/scenario/afficher_detailler/') . $pseudos['code'] . '">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                            <td class="icon-column">
                                <a href="' . base_url('index.php/scenario/modifier') . '">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </td>
                            <td class="icon-column">
                                <a href="' . base_url('index.php/scenario/ajouter') . '">
                                    <i class="fas fa-plus-circle"></i>
                                </a>
                            </td>
                            <td class="icon-column">
                                <a href="' . base_url('index.php/scenario/supprimer/') . $pseudos["ID"] . '" onclick="return confirm(\'Êtes-vous sûr de vouloir supprimer ce scénario et ses étapes associées ?\')">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </td>
                            <td class="icon-column">';
                                if ($pseudos["Active"] == 'oui') { 
                                    echo '<a href="' . base_url('index.php/scenario/desactiver/') . $pseudos["ID"] . '">
                                            <i class="fas fa-toggle-on"></i> 
                                        </a>';
                                } else { 
                                    echo '<a href="' . base_url('index.php/scenario/activer/') . $pseudos["ID"] . '">
                                            <i class="fas fa-toggle-off"></i> 
                                        </a>';
                                }
                            echo '</td>
                            <td class="icon-column">
                                <a href="' . base_url('index.php/scenario/remise_a_zero/') . $pseudos["ID"] . '" onclick="return confirm(\'Êtes-vous sûr de vouloir réinitialiser ce scénario ?\')">
                                    <i class="fas fa-undo"></i> 
                                </a>
                            </td>';
                    } else {
                        echo '<td class="icon-column">
                                <a href="' . base_url('index.php/scenario/afficher_detailler/') . $pseudos['code'] . '">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                            <td class="icon-column">
                            
                            </td>
                            <td class="icon-column">
                                <a href="' . base_url('index.php/scenario/ajouter') . '">
                                    <i class="fas fa-plus-circle"></i>
                                </a>
                            </td>';
                    }
                    echo '</tr>';
                }
            }
            ?>
        </tbody>
    </table>
</body>
</html>
