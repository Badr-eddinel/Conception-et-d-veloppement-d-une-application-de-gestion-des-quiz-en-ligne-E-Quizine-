
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
					  /* styles.css */
		h1.welcome-title {
			text-align: center;
			font-family: Arial, sans-serif;
			font-size: 28px;
			position: relative;
			margin-bottom: 20px; /* Ajustement de la marge en bas */
		}

		h1.welcome-title::before {
			content: "\1F389"; /* Code Unicode pour une icône de célébration */
			display: block;
			font-size: 36px;
			margin: 0 auto 15px; /* Ajustement de la marge pour l'espacement */
		}

		p.welcome-message {
			text-align: center;
			font-family: Arial, sans-serif;
			font-size: 16px;
			color: #666;
		}

    </style>
    <title>Tableau PHP</title>
</head>
<body>
	<br></br>
	<br></br>
	<br></br>
	<br></br>
	
    <h1 class="welcome-title"><?php echo "Bienvenue au Jeu";?></h1>
    <p class="welcome-message"><?php echo "C'est un plaisir de vous avoir parmi nous. Profitez de votre temps de jeu et amusez-vous bien !";?></p>
    <!-- Votre table et autres contenus -->
    <br></br>
	<br></br>
	<br></br>
	<br></br>
</body>
</html>



