<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout de Compte</title>
    <style>
        /* Styles CSS */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin-top: 50px;
        }
        
        .message-container {
            padding: 20px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: inline-block;
        }
        
        .success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        
        .error {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="message-container ">
		
        <?php echo $le_message; ?><br>
        
        <a href="<?= base_url('index.php/compte/afficher_profil') ?>" class="add-button">Cliquer ici</a>

        
    </div>
</body>
</html>
