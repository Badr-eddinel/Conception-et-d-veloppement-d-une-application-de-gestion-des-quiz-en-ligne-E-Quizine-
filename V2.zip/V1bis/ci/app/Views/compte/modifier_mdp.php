<!-- Doctype et entête de la page -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Création de compte</title>
  <style>
	  
	  .error-message {
        color: red;
      }
      body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .form-container {
				display: flex;
				flex-direction: column;
				align-items: center;
				
		}


        form {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }

        h2 {
            
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
        

        label {
            display: block;
            margin-top: 10px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: blue;
            color: white;
            cursor: pointer;
        }

        /* Styles pour le menu */
        .navbar {
            background-color: #eee;
            padding: 10px;
            text-align: center;
        }
        
        
    </style>
</head>
<body>
	
    <div class="form-container">
		<?php $session = session()?>
        <h2><?php echo ("Modifier le mot de passe"); ?></h2>
        <?= session()->getFlashdata('error') ?>
        <?php echo form_open('/compte/modifier'); ?>
        <?= csrf_field() ?>

      
       
        
        
        <label for="nom">Nom :</label>
        <input type="input" name="nom" value="<?php echo $compte->pfl_nom; ?>" readonly>
        <span class="error-message"><?= validation_show_error('nom') ?></span>

        <label for="prenom">Prénom :</label>
        <input type="input" name="prenom" value="<?php echo $compte->pfl_prenom; ?>" readonly>
        <span class="error-message"><?= validation_show_error('prenom') ?></span>

        <label for="pseudo">Pseudo :</label>
        <input type="input" name="pseudo" value="<?php echo $session->get('user'); ?>" readonly>
        <span class="error-message"><?= validation_show_error('pseudo') ?></span>


  

        

        <label for="mdp"> Nouveau Mot de passe :</label>
        <input type="password" name="mdp">
        <span class="error-message"><?= validation_show_error('mdp') ?></span>

        <label for="mdp_confirm">Confirmer le mot de passe :</label>
        <input type="password" name="mdp_confirm">
        <span class="error-message"><?= validation_show_error('mdp_confirm') ?></span>

       
		
		
		


        <input type="submit" name="submit" value="Modifier le mot de passe">
        
        </form>
        <a href="<?php echo base_url('index.php/compte/afficher_profil'); ?>" class="cancel-link">Annuler et retourner à la page</a>

    </div>
</body>
</html>
