




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .scenarios-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            padding: 20px;
        }

        .scenario {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            margin: 10px;
            width: 300px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .scenario h2 {
            color: #333;
            font-size: 1.5em;
            margin-bottom: 10px;
            display: flex;
            align-items: center; /* Aligne le texte et l'icône verticalement */
        }

        .scenario p {
            color: #666;
            font-size: 1em;
            margin: 0 0 15px 0;
        }




		.scenario a {
			color: #007bff; /* Couleur du lien */
			text-decoration: none; /* Supprimer le soulignement */
			font-weight: bold; /* Mettre en gras */
		}


		.scenario input[type='text'] {
			padding: 8px;
			margin-bottom: 10px;
			border: 1px solid #ccc;
			border-radius: 4px;
		}


		.scenario button {
			padding: 8px 16px;
			background-color: #007bff;
			color: white;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			transition: background-color 0.3s ease;
		}

		.scenario button:hover {
			background-color: #0056b3; /* Changement de couleur au survol */
		}
		scenario .question {
    font-weight: bold; /* Texte en gras */
    color: #FF5733; /* Couleur différente pour mettre en évidence */
    font-style: italic; /* Style italique */
}

    </style>
    <title>Tableau PHP</title>
</head>
<body>
	<div class="form-container">
    <?php
    // ... Affichage des données de l’étape ...
     echo form_open('/scenario/franchir_etape/'.$lecode.'/' . $lenv); 
    ?>
    <?= csrf_field() ?>

<div class="scenarios-container">
    <?php
    if (empty($Etape)) {
        echo "Pas etape disponibles pour le moment.";
    } elseif (isset($Etape)) {
        ?>
        
        <div class='scenario'>
            <h2><?php echo $Etape->IntituleEtape;?> <i class='fas fa-info-circle' onclick='afficherDetails()'></i></h2>
            <?php if (!empty($Etape->lien)) { ?>
                <p class='hidden' id='details'>Voici un indice qui peut vous aider : <a href='<?php echo $Etape->lien;?>'><?php echo $Etape->lien;?></a></p>
            <?php } else { ?>
                <p>Il n'y a pas d'indice disponible pour le moment.</p>
            <?php } ?>
            <p>Description: <?php echo $Etape->descr;?></p>
            <p>Question: <?php echo $Etape->ques;?></p>
            <!-- Formulaire pour la réponse -->
    <label for="reponse">Votre réponse :</label>
    <input type="input" name="reponse">
    
    <!-- Affichage du message juste au-dessus du bouton de soumission -->
    <?php if (!empty($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>

    <!-- Bouton de soumission -->
    <input type="submit" name="submit" value="Valider">
        </div>
    <?php
    }
    ?>
</div>
<script>
    function afficherDetails() {
        var details = document.getElementById('details');
        details.style.display = 'block';
    }
</script>





