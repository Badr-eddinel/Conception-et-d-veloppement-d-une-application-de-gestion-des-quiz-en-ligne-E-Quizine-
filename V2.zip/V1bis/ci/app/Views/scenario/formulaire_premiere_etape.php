<!-- Doctype et entête de la page -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Création de compte</title>
  <style>
	  
	  .error-message {
        color: red;
      }
      body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 50px; /* Ajout de marge en haut pour l'espace */
        }

        form {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%; /* Largeur du formulaire ajustée */
            max-width: 400px; /* Limite de la largeur pour une meilleure lisibilité */
            text-align: center;
        }

        h2 {
            
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
        

        label {
            display: block;
            margin-top: 10px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: blue;
            color: white;
            cursor: pointer;
        }

        /* Styles pour le menu */
        .navbar {
            background-color: #eee;
            padding: 10px;
            text-align: center;
        }
        
        
    </style>
</head>

<body>
 <div class="form-container">
    <?php echo form_open('/scenario/finaliser/'.$lecode.'/' . $lenv); ?>
    <?= csrf_field() ?>

    <?php if (!empty($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>

    <!-- Formulaire pour la réponse -->
    <label for="reponse">entrez votre adresse mail  :</label>
    <input type="input" name="reponse">
    
    
    
    <input type="submit" name="submit" value="Valider">

    <?= form_close() ?>
</div>
