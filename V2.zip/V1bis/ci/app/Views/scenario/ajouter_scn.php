<!-- Doctype et entête de la page -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Création de compte</title>
  <style>
	  
	  .error-message {
        color: red;
      }
      body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 50px; /* Ajout de marge en haut pour l'espace */
        }

        form {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%; /* Largeur du formulaire ajustée */
            max-width: 400px; /* Limite de la largeur pour une meilleure lisibilité */
            text-align: center;
        }

        h2 {
            
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
        

        label {
            display: block;
            margin-top: 10px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: blue;
            color: white;
            cursor: pointer;
        }

        /* Styles pour le menu */
        .navbar {
            background-color: #eee;
            padding: 10px;
            text-align: center;
        }
        
        
    </style>
</head>

<body>
    <div class="form-container">
        <h2><?php echo ("Ajouter un Scénario"); ?></h2>
        <?= session()->getFlashdata('error') ?>
        <?= form_open_multipart('/scenario/ajouter'); ?>
        <?= csrf_field() ?>
        <label for="intitule">intitule : </label>
        <input type="input" name="intitule">
        	<span class="error-message"><?= validation_show_error('intitule') ?></span>

        	<label for="description">description : </label>
        <input type="input" name="description">
        	<span class="error-message"><?= validation_show_error('description') ?></span>
		

		<label for="etat">État du Scénario:</label><br>
			<select id="etat" name="etat">
				<option value="A">Active</option>
				<option value="D">Désactivé</option>
			</select><br><br>
			<span class="error-message"><?= validation_show_error('etat') ?></span>
			
			<label for="fichier">Image pour le profil : </label>
<input type="file" name="fichier">
		<span class="error-message"><?= validation_show_error('fichier') ?></span>
		
		<input type="submit" name="submit" value="Ajouter un nouveau scenario">
         <a href="<?php echo base_url('index.php/scenario/afficher_detaille'); ?>" class="cancel-link">Annuler et retourner à la page avant</a>
        
    </div>

    
</body>
</html>

    
