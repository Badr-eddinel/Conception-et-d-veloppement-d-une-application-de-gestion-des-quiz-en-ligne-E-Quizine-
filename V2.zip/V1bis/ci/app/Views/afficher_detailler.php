<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        table {
            width: 80%;
            margin: 50px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
    <title>Tableau PHP</title>
</head>
<body>
    <h1><?php echo $titre;?></h1><br/> 	

    <table>
        
        <tbody>
          
           
             <?php
            if (empty($intitule) ) {
                    echo ("Pas scenario disponibles pour le moment.");
                     
                } 
            
                elseif (isset($intitule) )
{?>

                <thead>
            <tr>
                <th>ID</th>
                <th>Intitule</th>
                <th>Code</th>
                <th>Image</th>
                <th>Nombre Étapes</th>  
                <th>Description</th>
                <th>Active</th>
                <th>Auteur</th>
            </tr>
        </thead>
                 <?php
                  echo "<tr>";  
					echo "<td>" . $intitule->ID . "</td>";
					echo "<td>" . $intitule->Intitule . "</td>";
					echo "<td>" . $intitule->code . "</td>";
					echo "<td><img src='" . base_url('ressources/') . $intitule->img . "' width='100' height='100'></td>";
					echo "<td>" . $NB->NB . "</td>";
					echo "<td>" . $intitule->decription . "</td>";
					echo "<td>" . $intitule->Active . "</td>";
					echo "<td>" . $intitule->Auteur . "</td>";
					echo "</tr>";
                }
			 
			

				?>

            
        </tbody>
    </table>

    <h2>Liste des questions et réponses</h2>
    <table>
        
        <tbody>
			
			<?php
					if (empty($liste)) {
						echo ("Pas de question ou réponse disponible pour le moment.");
					} 
				
					elseif (isset($liste) )
						{ ?>
							
							<thead>
            <tr>
                <th>Question</th>
                <th>Réponse</th>
            </tr>
        </thead>
					<?php	foreach ($liste as $eta)
							{
								
									echo "<tr>";
									echo "<td>" . $eta["ques"] . "</td>";
									echo "<td>" . $eta["rep"] . "</td>";
									
									
									echo "</tr>";
							  }
						    } 
							


				?>
			
			
           
        </tbody>
    </table>
</body>
</html>
