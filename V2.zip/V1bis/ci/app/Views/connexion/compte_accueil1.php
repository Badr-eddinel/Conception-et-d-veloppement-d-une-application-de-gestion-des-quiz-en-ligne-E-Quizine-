<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Espace d'administration</title>
    <style>
        .title {
            text-align: center;
            margin-top: 50px; 
        }

        .title h2 {
            font-family: Arial, sans-serif;
            color: #333;
           
        }
    </style>
</head>
<body>
    <div class="title">
        <h2>Espace organisateur</h2>
        <br>
        <h2>Session ouverte ! Bienvenue
        <?php
        $session = session();
        echo $session->get('user');
        ?>
        </h2>
    </div>
</body>
</html>
