<!-- Doctype et entête de la page -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Création de compte</title>
  <style>
	  
	  .error-message {
        color: red;
      }
      body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .form-container {
				display: flex;
				flex-direction: column;
				align-items: center;
				
		}


        form {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }

        h2 {
            
            text-align: center;
            margin-top: 20px;
            color: #333;
        }
        

        label {
            display: block;
            margin-top: 10px;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            margin-bottom: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: blue;
            color: white;
            cursor: pointer;
        }

        /* Styles pour le menu */
        .navbar {
            background-color: #eee;
            padding: 10px;
            text-align: center;
        }
        
        
    </style>
</head>
<body>
	        
    <div class="form-container"> 
        <h2><?php echo $titre; ?></h2>
        <?php echo $message; ?>
        <?= session()->getFlashdata('error') ?>
        <?php echo form_open('/compte/connecter'); ?>
        <?= csrf_field() ?>
        
        <label for="pseudo">Pseudo : </label>
        <input type="input" name="pseudo" value="<?= set_value('pseudo') ?>">
        <?= validation_show_error('pseudo') ?>
        
        <label for="mdp">Mot de passe : </label>
        <input type="password" name="mdp">
        <?= validation_show_error('mdp') ?>
        
        <input type="submit" name="submit" value="Se connecter">
        </form>
    </div>
</body>
</html>
