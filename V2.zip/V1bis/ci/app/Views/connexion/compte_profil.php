

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        table {
            width: 80%;
            margin: 50px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
    <title>Tableau PHP</title>
</head>
<body>


    <table>
        
        <tbody>
	
		
			
			
            <?php
            if (empty($compte) ) {
                    echo ("Pas d profil disponibles pour le moment.");
                } 
            
                elseif (isset($compte) )
{?>

                <thead>
            <tr>
                <th>Prenom</th>
                <th>Nom</th>
                <th>Role</th>
                <th>Validite</th>
                <th>Auteur</th>
            </tr>
        </thead>
                 <?php
                  echo "<tr>";
                  echo "<td>" . $compte->pfl_prenom . "</td>";
                    echo "<td>" . $compte->pfl_nom . "</td>";
                    echo "<td>" . $compte->pfl_role . "</td>";
                    echo "<td>" . $compte->pfl_validite . "</td>";
                     echo "<td>" . $compte->cmp_login . "</td>";
                    
                    echo "</tr>";
                }
			 
			


            ?>
            <a href="<?= base_url('index.php/compte/modifier') ?>" class="add-button">modifier le mot de passe</a>
            
        </tbody>
    </table>

</body>
</html>
