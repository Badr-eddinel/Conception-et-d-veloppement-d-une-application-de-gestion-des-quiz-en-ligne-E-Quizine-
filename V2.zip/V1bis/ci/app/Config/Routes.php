<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Accueil::afficher');







use App\Controllers\Accueil;
$routes->get('accueil/afficher', [Accueil::class, 'afficher']);






use App\Controllers\Compte;
$routes->get('compte/lister', [Compte::class, 'lister']);
$routes->match(["get","post"],'compte/creer', [Compte::class, 'creer']);
$routes->get('compte/connecter', [Compte::class, 'connecter']);
$routes->post('compte/connecter', [Compte::class, 'connecter']);
$routes->get('compte/deconnecter', [Compte::class, 'deconnecter']);
$routes->get('compte/afficher_profil', [Compte::class, 'afficher_profil']);
$routes->match(["get","post"],'compte/modifier', [Compte::class, 'modifier']);



use App\Controllers\Actualite;
$routes->get('actualite/afficher', [Actualite::class, 'afficher']);
$routes->get('actualite/afficherone/(:num)', [Actualite::class, 'afficherone']);

use App\Controllers\Scenario;
$routes->get('scenario/afficher', [Scenario::class, 'afficher']);
$routes->get('scenario/afficher_detaille', [Scenario::class, 'afficher_detaille']);
$routes->get('scenario/afficher_detailler/(:segment)', [Scenario::class, 'afficher_detailler']);
$routes->get('scenario/afficher_detailler', [Scenario::class, 'afficher_detailler']);
$routes->get('scenario/active/(:num)', [Scenario::class, 'active']);
$routes->get('scenario/desactive/(:num)', [Scenario::class, 'desactive']);

$routes->match(["get","post"],'scenario/ajouter', [Scenario::class, 'ajouter']);
$routes->get('scenario/supprimer/(:num)', [Scenario::class, 'supprimer']);

$routes->get('scenario/franchir_etape/(:segment)/(:num)', [Scenario::class, 'franchir_etape/$1/$2']);
$routes->post('scenario/franchir_etape/(:segment)/(:num)', [Scenario::class, 'franchir_etape/$1/$2']);

$routes->get('scenario/franchir_etape/(:segment)', [Scenario::class, 'franchir_etape']);
$routes->get('scenario/franchir_etape/(:segment)/(:num)', [Scenario::class, 'franchir_etape']);
$routes->get('scenario/franchir_etape', [Accueil::class, 'afficher']);


$routes->get('scenario/finaliser/(:segment)/(:num)', [Scenario::class, 'finaliser/$1/$2']);
$routes->post('scenario/finaliser/(:segment)/(:num)', [Scenario::class, 'finaliser/$1/$2']);

use App\Controllers\Etape;
$routes->get('etape/affiche', [Accueil::class, 'afficher']);

$routes->get('etape/affiche/(:segment)', [Accueil::class, 'afficher']);
//$routes->get('etape/affiche/(:segment)/(:segment)', [Etape::class, 'affiche']);
//$routes->get('etape/affiche/(:segment)/(:segment)', 'Etape::affiche/$1/$2');

$routes->get('etape/affiche/(:segment)/(:num)', [Etape::class, 'affiche']);
$routes->post('etape/affiche/(:segment)/(:num)', [Etape::class, 'affiche/$1/$2']);
$routes->post('etape/affiche/', [Etape::class, 'affiche']);


